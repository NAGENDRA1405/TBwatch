import { useMemo, useRef, useState } from 'react'
import { Bar } from 'react-chartjs-2'
import {
  BarElement,
  CategoryScale,
  Chart as ChartJS,
  Legend,
  LinearScale,
  Tooltip,
} from 'chart.js'
import './App.css'

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip, Legend)

const schemaFields = [
  { key: 'Cattle_ID', label: 'Cattle ID' },
  { key: 'Breed', label: 'Breed' },
  { key: 'Age (Years)', label: 'Age (Years)', type: 'number', step: '0.1' },
  {
    key: 'Sex',
    label: 'Sex',
    type: 'select',
    options: [
      { label: 'Male', value: 'M' },
      { label: 'Female', value: 'F' },
    ],
    defaultValue: 'M',
  },
  { key: 'Location', label: 'Location' },
  {
    key: 'TB_Sympt',
    label: 'TB Symptoms',
    type: 'select',
    options: [
      { label: 'No', value: 'N' },
      { label: 'Yes', value: 'Y' },
    ],
    defaultValue: 'N',
  },
  {
    key: 'TB_Skin_T',
    label: 'TB Skin Test',
    type: 'select',
    options: [
      { label: 'Negative', value: 'Negative' },
      { label: 'Positive', value: 'Positive' },
    ],
    defaultValue: 'Negative',
  },
  { key: 'Lab_Resul', label: 'Lab Result' },
  {
    key: 'TB_Status',
    label: 'TB Status (optional)',
    type: 'select',
    options: [
      { label: '(Unknown)', value: '' },
      { label: 'Healthy', value: 'Healthy' },
      { label: 'Infected', value: 'Infected' },
    ],
    defaultValue: '',
  },
  { key: 'Date_Test', label: 'Date Tested', type: 'date' },
  { key: 'Farm_Mar', label: 'Farm Manager' },
  { key: 'Outcome', label: 'Outcome' },
]

const featureFields = [
  { key: 'ID', label: 'Record ID (optional)' },
  { key: 'age_months', label: 'Age (months)', type: 'number', step: '1', defaultValue: 36 },
  { key: 'weight_kg', label: 'Weight (kg)', type: 'number', step: '1', defaultValue: 420 },
  { key: 'body_temperature', label: 'Body temperature (°C)', type: 'number', step: '0.1', defaultValue: 38.6 },
  { key: 'respiratory_rate', label: 'Respiratory rate (breaths/min)', type: 'number', step: '0.1', defaultValue: 28 },
  { key: 'cough_frequency', label: 'Cough frequency (per day)', type: 'number', step: '1', defaultValue: 0 },
  { key: 'appetite_level', label: 'Appetite level (0-10)', type: 'number', step: '1', defaultValue: 9 },
  { key: 'milk_production_liters', label: 'Milk production (liters/day)', type: 'number', step: '0.1', defaultValue: 15 },
  { key: 'lymph_node_swelling', label: 'Lymph node swelling score (0-10)', type: 'number', step: '1', defaultValue: 0 },
  { key: 'lethargy_score', label: 'Lethargy score (0-10)', type: 'number', step: '1', defaultValue: 1 },
  {
    key: 'exposure_to_infected',
    label: 'Exposure to infected (0 or 1)',
    type: 'number',
    step: '1',
    defaultValue: 0,
  },
  {
    key: 'tb_status',
    label: 'True TB status (optional, 0 healthy / 1 TB)',
    type: 'number',
    step: '1',
    defaultValue: '',
    helper: 'Optional: use only if you know the confirmed diagnosis.',
  },
]

const buildInitialFormState = (fields) =>
  fields.reduce((acc, field) => {
    acc[field.key] = field.defaultValue ?? ''
    return acc
  }, {})

const currencyFormatter = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0,
})

const formatMoney = (value) => currencyFormatter.format(Math.max(0, Number(value) || 0))

const API_BASE = (import.meta.env.VITE_API_BASE || 'http://127.0.0.1:5000').replace(/\/$/, '')
const apiUrl = (path) => `${API_BASE}${path}`

function App() {
  const [inputMode, setInputMode] = useState('schema')
  const [schemaForm, setSchemaForm] = useState(() => buildInitialFormState(schemaFields))
  const [featureForm, setFeatureForm] = useState(() => buildInitialFormState(featureFields))
  const [manualResult, setManualResult] = useState(null)
  const [manualError, setManualError] = useState('')
  const [manualLoading, setManualLoading] = useState(false)

  const [evalData, setEvalData] = useState(null)
  const [uploadError, setUploadError] = useState('')
  const [uploading, setUploading] = useState(false)
  const [selectedId, setSelectedId] = useState('')
  const fileInputRef = useRef(null)

  const handleSchemaFieldChange = (key) => (event) => {
    const value = event.target.value
    setSchemaForm((prev) => ({ ...prev, [key]: value }))
  }

  const handleFeatureFieldChange = (key) => (event) => {
    const value = event.target.value
    setFeatureForm((prev) => ({ ...prev, [key]: value }))
  }

  const handleManualSubmit = async (event) => {
    event.preventDefault()
    setManualError('')
    setManualLoading(true)
    try {
      const submission = inputMode === 'schema' ? schemaForm : featureForm
      const endpoint =
        inputMode === 'schema' ? '/api/predict-from-schema' : '/api/predict-from-features'
      const response = await fetch(apiUrl(endpoint), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(submission),
      })
      const responseBody = await response.json()
      if (!response.ok) {
        throw new Error(responseBody.error || 'Request failed. Please try again.')
      }
      setManualResult(responseBody)
    } catch (error) {
      setManualResult(null)
      setManualError(error.message || 'Unexpected error')
    } finally {
      setManualLoading(false)
    }
  }

  const handleUpload = async () => {
    if (!fileInputRef.current?.files?.length) {
      setUploadError('Choose a CSV file to evaluate.')
      return
    }
    setUploadError('')
    setUploading(true)
    setSelectedId('')
    try {
      const fd = new FormData()
      fd.append('file', fileInputRef.current.files[0])
      const response = await fetch(apiUrl('/api/evaluate-upload'), {
        method: 'POST',
        body: fd,
      })
      const payload = await response.json()
      if (!response.ok) {
        throw new Error(payload.error || 'Upload failed. Please try again.')
      }
      setEvalData(payload)
    } catch (error) {
      setEvalData(null)
      setUploadError(error.message || 'Unexpected error')
    } finally {
      setUploading(false)
    }
  }

  const selectedItem = useMemo(() => {
    if (!selectedId || !evalData?.items) return null
    return evalData.items.find((item) => String(item.id) === String(selectedId))
  }, [selectedId, evalData])

  const manualChartData = useMemo(() => {
    if (!manualResult?.top_risk_factors?.length) return null
    return {
      labels: manualResult.top_risk_factors.map((factor) => factor.factor),
      datasets: [
        {
          label: 'Importance',
          borderRadius: 6,
          backgroundColor: '#3b82f6',
          data: manualResult.top_risk_factors.map((factor) => factor.importance),
        },
      ],
    }
  }, [manualResult])

  const accuracySummary = useMemo(() => {
    const metrics = evalData?.metrics
    if (!metrics) return ''
    if (typeof metrics.accuracy === 'number') {
      const cm = metrics.confusion_matrix || {}
      return `Accuracy: ${(metrics.accuracy * 100).toFixed(2)}%
TN=${cm.true_negative ?? 0}, FP=${cm.false_positive ?? 0}, FN=${cm.false_negative ?? 0}, TP=${cm.true_positive ?? 0}`
    }
    return metrics.warning || ''
  }, [evalData])

  const diagnosticsSummary = useMemo(() => {
    const diag = evalData?.diagnostics
    if (!diag) return ''
    return `Label column: ${diag.label_column}
Rows with valid labels: ${diag.valid_label_rows}/${diag.total_rows}
Raw counts: ${JSON.stringify(diag.raw_value_counts, null, 2)}`
  }, [evalData])

  const timestampLabel = (isoString) => {
    if (!isoString) return 'Not available'
    const parsed = new Date(isoString)
    return Number.isNaN(parsed.getTime()) ? 'Not available' : parsed.toLocaleString()
  }

  return (
    <div className="app-shell">
      <header>
        <p className="eyebrow">Cattle TB AI</p>
        <h1>ML-assisted tuberculosis triage</h1>
        <p className="lead">
          Capture an individual record or bulk upload a CSV to score cattle with the Flask backend.
        </p>
      </header>

      <section className="panel">
        <h2>Manual entry</h2>
        <p className="section-hint">
          Toggle between your legacy cattle schema and the raw model feature columns (age_months,
          weight_kg, etc.) so operators can supply whichever data they have available.
        </p>

        <form className="schema-form" onSubmit={handleManualSubmit}>
          <div className="input-mode-toggle">
            {[
              { key: 'schema', label: 'Your schema' },
              { key: 'features', label: 'Model features' },
            ].map((mode) => (
              <button
                key={mode.key}
                type="button"
                className={`mode-chip ${inputMode === mode.key ? 'active' : ''}`}
                onClick={() => setInputMode(mode.key)}
              >
                {mode.label}
              </button>
            ))}
          </div>

          <div className="field-grid">
            {(inputMode === 'schema' ? schemaFields : featureFields).map((field) => {
              const value =
                inputMode === 'schema' ? schemaForm[field.key] ?? '' : featureForm[field.key] ?? ''
              const handler =
                inputMode === 'schema'
                  ? handleSchemaFieldChange(field.key)
                  : handleFeatureFieldChange(field.key)
              return (
              <label key={field.key} className="field">
                <span>{field.label}</span>
                {field.type === 'select' ? (
                    <select value={value} onChange={handler}>
                    {field.options?.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                ) : (
                  <input
                    type={field.type || 'text'}
                      value={value}
                      onChange={handler}
                    step={field.step}
                      min={field.min}
                      max={field.max}
                  />
                  )}
                  {field.helper && <small className="helper">{field.helper}</small>}
                </label>
              )
            })}
          </div>

          {manualError && <div className="error">{manualError}</div>}

          <div className="button-row">
            <button type="submit" disabled={manualLoading}>
              {manualLoading ? 'Predicting…' : 'Predict'}
            </button>
            <button
              type="button"
              className="ghost"
              onClick={() => {
                if (inputMode === 'schema') {
                  setSchemaForm(buildInitialFormState(schemaFields))
                } else {
                  setFeatureForm(buildInitialFormState(featureFields))
                }
                setManualResult(null)
                setManualError('')
              }}
            >
              Reset form
            </button>
          </div>
        </form>

        {manualResult && (
          <div className="card result-card">
            <div className="result-header">
              <div>
                <p className="eyebrow">#{manualResult.cattle_id || 'manual record'}</p>
                <h3>{manualResult.prediction}</h3>
              </div>
              <div className={`risk-pill ${manualResult.risk_level?.toLowerCase()}`}>
                {manualResult.risk_level} risk
              </div>
            </div>

            <div className="result-grid">
              <div>
                <p>TB probability</p>
                <strong>{(manualResult.tb_probability * 100).toFixed(1)}%</strong>
              </div>
              <div>
                <p>Healthy probability</p>
                <strong>{(manualResult.healthy_probability * 100).toFixed(1)}%</strong>
              </div>
              <div>
                <p>Confidence</p>
                <strong>{(manualResult.confidence * 100).toFixed(1)}%</strong>
              </div>
              <div>
                <p>Timestamp</p>
                <strong>{timestampLabel(manualResult.timestamp)}</strong>
              </div>
            </div>

            {manualResult.financial_impact && (
              <div className="money-grid">
                {Object.entries(manualResult.financial_impact)
                  .filter(([key]) => key !== 'currency')
                  .map(([key, value]) => (
                    <div key={key}>
                      <p>{key.replace(/_/g, ' ')}</p>
                      <strong>{formatMoney(value)}</strong>
                    </div>
                  ))}
              </div>
            )}

            {manualChartData && (
              <div className="chart-wrapper">
                <Bar
                  data={manualChartData}
                  options={{
                    responsive: true,
                    plugins: { legend: { display: false } },
                    scales: { y: { beginAtZero: true } },
                  }}
                />
              </div>
            )}

            <div>
              <h4>Top risk factors</h4>
              <ul className="risk-list">
                {manualResult.top_risk_factors?.map((factor) => (
                  <li key={factor.factor}>
                    <span>{factor.factor}</span>
                    <span>{(factor.importance * 100).toFixed(1)}%</span>
                  </li>
                ))}
              </ul>
            </div>

      <div>
              <h4>Recommendations</h4>
              <ul className="recommendations">
                {manualResult.recommendations?.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
      </div>
        )}
      </section>

      <section className="panel">
        <h2>Dataset upload</h2>
        <p className="section-hint">
          Upload a CSV to compute predictions, accuracy, and diagnostics in bulk.
        </p>

        <div className="upload-controls">
          <input ref={fileInputRef} type="file" accept=".csv" />
          <button type="button" onClick={handleUpload} disabled={uploading}>
            {uploading ? 'Processing…' : 'Upload & evaluate'}
          </button>
        </div>

        {uploadError && <div className="error">{uploadError}</div>}

        {evalData && (
          <>
            <div className="card metrics-card">
              <h3>Evaluation summary</h3>
              <p>
                Records scored: <strong>{evalData.count}</strong>
              </p>
              {accuracySummary && <pre className="code-block">{accuracySummary}</pre>}
              {diagnosticsSummary && (
                <>
                  <p className="eyebrow">Diagnostics</p>
                  <pre className="code-block">{diagnosticsSummary}</pre>
                </>
              )}
            </div>

            <div className="card selection-card">
              <label className="field">
                <span>Select {evalData.id_column || 'ID'}</span>
                <select value={selectedId} onChange={(e) => setSelectedId(e.target.value)}>
                  <option value="">-- choose an ID --</option>
                  {evalData.items?.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.id}
                    </option>
                  ))}
                </select>
              </label>

              {selectedItem ? (
                <div className="selected-details">
                  <div className="result-header selected-header">
                    <div>
                      <p className="eyebrow">ID: {selectedItem.id}</p>
                      <h3>{selectedItem.prediction}</h3>
                    </div>
                    <div className={`risk-pill ${selectedItem.risk_level?.toLowerCase()}`}>
                      {selectedItem.risk_level} risk
                    </div>
      </div>
                  <p>
                    TB probability {(selectedItem.tb_probability * 100).toFixed(1)}% • Healthy probability{' '}
                    {(selectedItem.healthy_probability * 100).toFixed(1)}%
                  </p>
                  {selectedItem.true_label !== null && selectedItem.true_label !== undefined && (
                    <p>
                      True label:{' '}
                      <strong>{selectedItem.true_label === 1 ? 'TB' : 'Healthy'}</strong> (
                      {selectedItem.pred_label === selectedItem.true_label ? 'match' : 'mismatch'})
                    </p>
                  )}
                  {selectedItem.financial_impact && (
                    <div className="money-grid">
                      {Object.entries(selectedItem.financial_impact)
                        .filter(([key]) => key !== 'currency')
                        .map(([key, value]) => (
                          <div key={key}>
                            <p>{key.replace(/_/g, ' ')}</p>
                            <strong>{formatMoney(value)}</strong>
                          </div>
                        ))}
                    </div>
                  )}

                  <div>
                    <h4>Top risk factors</h4>
                    <ul className="risk-list">
                      {selectedItem.top_risk_factors?.map((factor) => (
                        <li key={factor.factor}>
                          <span>{factor.factor}</span>
                          <span>{(factor.importance * 100).toFixed(1)}%</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4>Recommendations</h4>
                    <ul className="recommendations">
                      {selectedItem.recommendations?.map((item) => (
                        <li key={item}>{item}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              ) : (
                <p className="section-hint">Pick an animal ID to inspect its prediction.</p>
              )}
            </div>
          </>
        )}
      </section>
    </div>
  )
}

export default App
