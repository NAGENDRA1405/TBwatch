## Cattle TB AI

Modernised full-stack application for cattle tuberculosis risk analysis. The backend is a Flask API that generates synthetic training data, fits a RandomForest model, and serves scoring endpoints. The frontend is a React + Vite dashboard that mirrors the original schema for manual entry and CSV uploads, rendering insights with Chart.js.

### Project layout
- `backend/` – Flask app (`app.py`) and Python dependencies in `requirements.txt`.
- `frontend/` – Vite-powered React UI (`npm run dev` / `npm run build`).

### Prerequisites
- Python 3.10+
- Node.js 18+ and npm

### Backend setup
```bash
cd backend
python -m venv .venv
.venv\Scripts\activate        # Windows
pip install -r requirements.txt
python app.py
```
The API listens on `http://127.0.0.1:5000` by default. CORS is enabled for local development.

### Frontend setup
```bash
cd frontend
npm install
npm run dev
```
Create a `.env` file in `frontend/` if you need to override the backend URL (defaults to `http://127.0.0.1:5000`):
```
VITE_API_BASE=http://127.0.0.1:5000
```

`npm run build` outputs production assets to `frontend/dist`.

### Manual prediction options
- **Schema mode**: Fill out the legacy cattle-record form; the UI sends the payload to `/api/predict-from-schema` (existing behaviour).
- **Model feature mode**: Enter the exact feature columns used by the RandomForest (age_months, weight_kg, etc.). These values are sent to `/api/predict-from-features`, ensuring full control over the numeric inputs the model consumes.

