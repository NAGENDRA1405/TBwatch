from flask import Flask, request, jsonify
from flask_cors import CORS
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, confusion_matrix
import joblib
import os
from datetime import datetime

app = Flask(__name__)
CORS(app)

model = None
scaler = None

feature_names = [
    'age_months', 'weight_kg', 'body_temperature', 'respiratory_rate',
    'cough_frequency', 'appetite_level', 'milk_production_liters',
    'lymph_node_swelling', 'lethargy_score', 'exposure_to_infected'
]


def _coerce_feature_payload(payload: dict):
    parsed = {}
    missing = []
    for name in feature_names:
        raw = payload.get(name)
        if raw is None or (isinstance(raw, str) and raw.strip() == ''):
            missing.append(name)
            continue
        try:
            parsed[name] = float(raw)
        except Exception as exc:
            raise ValueError(f"Invalid numeric value for '{name}': {raw}") from exc
    if missing:
        raise ValueError(f"Missing required feature(s): {', '.join(missing)}")
    return parsed

def _top_risk_factors():
    importance = dict(zip(feature_names, model.feature_importances_))
    return [
        {'factor': k, 'importance': float(v)}
        for k, v in sorted(importance.items(), key=lambda x: x[1], reverse=True)[:5]
    ]

def _build_prediction_response(pred_label: int, prob_vec):
    p0 = float(prob_vec[0]); p1 = float(prob_vec[1])
    risk = 'High' if p1 > 0.7 else 'Medium' if p1 > 0.4 else 'Low'
    if pred_label == 1:
        treatment_cost = int(np.random.randint(5000, 15000))
        milk_loss = int(np.random.randint(2000, 5000))
        quarantine_cost = int(np.random.randint(500, 1500))
        total_loss = treatment_cost + milk_loss + quarantine_cost
    else:
        treatment_cost = milk_loss = quarantine_cost = total_loss = 0
    return {
        'prediction': 'TB Detected' if pred_label == 1 else 'Healthy',
        'confidence': float(max(p0, p1)),
        'tb_probability': p1,
        'healthy_probability': p0,
        'risk_level': risk,
        'financial_impact': {
            'treatment_cost_inr': treatment_cost,
            'milk_loss_inr': milk_loss,
            'quarantine_cost_inr': quarantine_cost,
            'total_loss_inr': total_loss,
            'currency': 'INR'
        },
        'recommendations': get_recommendations(pred_label, p1),
        'top_risk_factors': _top_risk_factors(),
        'timestamp': datetime.now().isoformat()
    }

def _normalize_label(x):
    if pd.isna(x): return None
    if isinstance(x, (int, np.integer)): return int(x)
    if isinstance(x, (float, np.floating)):
        if np.isnan(x): return None
        return int(round(float(x)))
    s = str(x).strip().lower()
    mapping = {
        '1': 1, '0': 0,
        'tb': 1, 'tb detected': 1,
        'positive': 1, 'pos': 1, 'pos.': 1, '+': 1,
        'reactive': 1, 'reactive tb': 1,
        'yes': 1, 'y': 1, 'true': 1, 't': 1,
        'infected': 1, 'diseased': 1,
        'healthy': 0, 'negative': 0, 'neg': 0, 'neg.': 0, '-': 0,
        'non reactive': 0, 'non-reactive': 0, 'nonreactive': 0,
        'no': 0, 'n': 0, 'false': 0, 'f': 0,
        'not infected': 0, 'normal': 0
    }
    return mapping.get(s, None)

def _find_col(df: pd.DataFrame, candidates):
    cols = {c.lower().strip(): c for c in df.columns}
    for name in candidates:
        key = name.lower().strip()
        if key in cols: return cols[key]
    relaxed = {c.lower().replace(' ', '').replace('_', ''): c for c in df.columns}
    for name in candidates:
        key = name.lower().replace(' ', '').replace('_', '')
        if key in relaxed: return relaxed[key]
    return None

def _features_from_row(row: pd.Series):
    # Defaults
    age_months = 36.0
    weight_kg = 420.0
    body_temp = 38.6
    resp_rate = 28.0
    cough_freq = 0.0
    appetite = 9.0
    milk_liters = 15.0
    lymph_swelling = 0.0
    lethargy = 1.0
    exposure = 0.0

    # Age (Years -> months)
    for cand in ['Age (Years)', 'Age Years', 'Age', 'age_years', 'age']:
        if cand in row.index:
            try:
                val = float(str(row[cand]).split()[0])
                age_months = max(0.0, val * 12.0)
                break
            except Exception:
                pass

    # Sex affects milk production
    sex_col = _find_col(row.to_frame().T, ['Sex'])
    if sex_col:
        s = str(row[sex_col]).strip().upper()
        if s in ['M', 'MALE']: milk_liters = 0.0

    # TB_Sympt (Y/N)
    sympto_col = _find_col(row.to_frame().T, ['TB_Sympt', 'TB_Sympto', 'Symptoms', 'Symptomatic'])
    if sympto_col:
        sy = str(row[sympto_col]).strip().lower()
        if sy in ['y', 'yes', 'true', '1']:
            cough_freq = 7.0; appetite = 4.0
            lymph_swelling = 5.0; lethargy = 6.0
            body_temp = 39.3; resp_rate = 34.0

    # TB_Skin_T (Positive/Negative)
    skin_col = _find_col(row.to_frame().T, ['TB_Skin_T', 'TB_Skin', 'TB Skin', 'TB Test', 'TB_Skin_Test'])
    if skin_col:
        sk = str(row[skin_col]).strip().lower()
        if sk in ['positive', 'pos', '1', 'tb', 'reactive']:
            exposure = 1.0
            body_temp = max(body_temp, 39.0)
            resp_rate = max(resp_rate, 32.0)

    return [age_months, weight_kg, body_temp, resp_rate, cough_freq,
            appetite, milk_liters, lymph_swelling, lethargy, exposure]

def generate_training_data(n_samples=1000):
    np.random.seed(42)
    data = []
    for i in range(n_samples):
        if i < n_samples * 0.6:
            age = np.random.randint(12, 120)
            weight = np.random.normal(450, 80)
            temp = np.random.normal(38.5, 0.3)
            resp_rate = np.random.normal(26, 4)
            cough = np.random.randint(0, 2)
            appetite = np.random.randint(8, 11)
            milk = np.random.normal(20, 5)
            lymph = np.random.randint(0, 2)
            lethargy = np.random.randint(0, 3)
            exposure = np.random.randint(0, 2)
            tb_status = 0
        else:
            age = np.random.randint(24, 120)
            weight = np.random.normal(380, 70)
            temp = np.random.normal(39.5, 0.5)
            resp_rate = np.random.normal(35, 6)
            cough = np.random.randint(5, 11)
            appetite = np.random.randint(2, 6)
            milk = np.random.normal(12, 4)
            lymph = np.random.randint(5, 11)
            lethargy = np.random.randint(6, 11)
            exposure = 1
            tb_status = 1
        data.append([age, weight, temp, resp_rate, cough, appetite, milk,
                     lymph, lethargy, exposure, tb_status])
    df = pd.DataFrame(data, columns=feature_names + ['tb_status'])
    return df

def train_model():
    global model, scaler
    df = generate_training_data(1000)
    X, y = df[feature_names], df['tb_status']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_test_s = scaler.transform(X_test)
    model = RandomForestClassifier(n_estimators=200, max_depth=12, min_samples_split=4,
                                   min_samples_leaf=2, class_weight={0:1.0,1:1.2}, random_state=42)
    model.fit(X_train_s, y_train)
    os.makedirs('models', exist_ok=True)
    joblib.dump(model, 'models/rf_model.pkl')
    joblib.dump(scaler, 'models/scaler.pkl')

def load_model():
    global model, scaler
    try:
        model = joblib.load('models/rf_model.pkl')
        scaler = joblib.load('models/scaler.pkl')
    except Exception:
        train_model()

@app.route('/api/health', methods=['GET'])
def health(): return jsonify({'status': 'ok', 'ts': datetime.now().isoformat()})

@app.route('/api/predict-from-schema', methods=['POST'])
def predict_from_schema():
    # Accepts your schema fields for a single animal
    data = request.json or {}
    # Build a faux row with your headers so we can reuse _features_from_row
    row = pd.Series({
        'Cattle_ID': data.get('Cattle_ID'),
        'Breed': data.get('Breed'),
        'Age (Years)': data.get('Age (Years)'),
        'Sex': data.get('Sex'),
        'Location': data.get('Location'),
        'TB_Sympt': data.get('TB_Sympt'),
        'TB_Skin_T': data.get('TB_Skin_T'),
        'Lab_Resul': data.get('Lab_Resul'),
        'TB_Status': data.get('TB_Status'),
        'Date_Test': data.get('Date_Test'),
        'Farm_Mar': data.get('Farm_Mar'),
        'Outcome': data.get('Outcome'),
    })
    feats = _features_from_row(row)
    feats_s = scaler.transform([feats])
    pred_label = int(model.predict(feats_s)[0])
    prob_vec = model.predict_proba(feats_s)[0]
    resp = _build_prediction_response(pred_label, prob_vec)
    resp['cattle_id'] = data.get('Cattle_ID')
    return jsonify(resp)

@app.route('/api/evaluate-upload', methods=['POST'])
def evaluate_upload():
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'Upload a CSV file under field name "file"'}), 400
        file = request.files['file']
        df = pd.read_csv(file)

        id_col = _find_col(df, ['Cattle_ID', 'cattle_id', 'animal_id', 'serial_no', 'serial', 'id'])
        if id_col is None:
            df = df.copy(); df['id'] = np.arange(1, len(df)+1); id_col = 'id'

        # Build features from your schema
        feats = df.apply(_features_from_row, axis=1, result_type='expand')
        feats.columns = feature_names
        X_scaled = scaler.transform(feats)
        prob_mat = model.predict_proba(X_scaled)
        pred = np.argmax(prob_mat, axis=1).astype(int)

        # Label detection
        label_col = _find_col(df, ['TB_Status', 'tb_status', 'Status', 'label', 'result', 'disease', 'TB_Skin_T', 'TB_Skin'])
        metrics = {}; diagnostics = {}
        if label_col is not None:
            y_raw = df[label_col]
            y_norm = y_raw.apply(_normalize_label)
            mask = y_norm.isin([0,1])
            diagnostics = {
                'label_column': label_col,
                'total_rows': int(len(df)),
                'valid_label_rows': int(mask.sum()),
                'raw_value_counts': {str(k): int(v) for k, v in y_raw.astype(str).str.strip().str.lower().value_counts().to_dict().items()}
            }
            if mask.any():
                y_valid = y_norm[mask].astype(int).values
                pred_valid = pred[mask.values]
                acc = accuracy_score(y_valid, pred_valid)
                cm = confusion_matrix(y_valid, pred_valid, labels=[0,1])
                metrics = {
                    'accuracy': float(acc),
                    'confusion_matrix': {
                        'true_negative': int(cm[0][0]),
                        'false_positive': int(cm[0][1]),
                        'false_negative': int(cm[1][0]),
                        'true_positive': int(cm[1][1])
                    }
                }
            else:
                metrics = {'warning': f'No valid labels found in {label_col} to compute accuracy.'}

        items = []
        top_feats = _top_risk_factors()
        for i in range(len(df)):
            p0, p1 = float(prob_mat[i][0]), float(prob_mat[i][1])
            item_resp = _build_prediction_response(int(pred[i]), [p0, p1])
            entry = {
                'id': df.iloc[i][id_col].item() if hasattr(df.iloc[i][id_col], 'item') else df.iloc[i][id_col],
                **item_resp,
                'pred_label': int(pred[i]),
                'true_label': None
            }
            if label_col is not None:
                tl = _normalize_label(df.iloc[i][label_col])
                entry['true_label'] = int(tl) if tl in (0,1) else None
            entry['top_risk_factors'] = top_feats
            items.append(entry)

        return jsonify({
            'id_column': id_col,
            'count': len(items),
            'metrics': metrics,
            'diagnostics': diagnostics,
            'items': items
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@app.route('/api/predict-from-features', methods=['POST'])
def predict_from_features():
    try:
        payload = request.json or {}
        parsed = _coerce_feature_payload(payload)
        feats = [parsed[name] for name in feature_names]
        feats_s = scaler.transform([feats])
        pred_label = int(model.predict(feats_s)[0])
        prob_vec = model.predict_proba(feats_s)[0]
        resp = _build_prediction_response(pred_label, prob_vec)
        resp['cattle_id'] = payload.get('ID') or payload.get('id') or payload.get('cattle_id')
        resp['submitted_features'] = parsed
        tb_status = _normalize_label(payload.get('tb_status'))
        if tb_status in (0, 1):
            resp['submitted_tb_status'] = tb_status
        resp['input_mode'] = 'features'
        return jsonify(resp)
    except ValueError as verr:
        return jsonify({'error': str(verr)}), 400
    except Exception as exc:
        return jsonify({'error': str(exc)}), 400

def get_recommendations(prediction, probability):
    if prediction == 1 or probability > 0.4:
        return [
            "Immediate veterinary consultation required",
            "Isolate the animal from the herd to prevent spread",
            "Conduct tuberculin skin test for confirmation",
            "Review and improve biosecurity measures",
            "Monitor other animals in contact for symptoms",
            "Consider financial assistance programs for treatment"
        ]
    else:
        return [
            "Maintain regular health monitoring",
            "Continue balanced nutrition and hygiene",
            "Schedule routine veterinary check-ups",
            "Keep vaccination records updated",
            "Monitor for any symptoms regularly"
        ]

load_model()

if __name__ == '__main__':
    print("Cattle TB AI Flask backend is running successfully!")
    app.run(debug=True, host='0.0.0.0', port=5000)